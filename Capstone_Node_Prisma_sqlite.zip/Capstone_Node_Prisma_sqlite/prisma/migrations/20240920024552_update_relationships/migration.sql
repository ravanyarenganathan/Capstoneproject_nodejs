-- DropIndex
DROP INDEX "Exercise_userId_key";
